`%^%` <-
function(A, power) matrixpwr(A, power)
