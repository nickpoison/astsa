\name{econ5}
\alias{econ5}
\docType{data}
\title{Five Quarterly Economic Series
} 
\description{Multiple time series of quarterly U.S. unemployment, GNP, consumption, and government and private investment, from 1948-III to 1988-II.
}
\format{
Multiple time series with 161 observations (rows) on the following 5 numeric variables (columns):  \code{unemp}, \code{gnp}, \code{consum}, \code{govinv},     \code{prinv}.
}
\source{Young, P.C. and Pedregal, D.J. (1999). Macro-economic relativity: government spending, private investment and unemployment in the USA 1948-1998. \emph{Structural Change and Economic Dynamics}, 10, 359-380.
}
\note{
\code{unemp} is in percentage (of the labor force), and the others are in 1982 Billions USD.
}
\references{You can find demonstrations of  astsa capabilities at  
\href{https://github.com/nickpoison/astsa/blob/master/fun_with_astsa/fun_with_astsa.md}{FUN WITH ASTSA}.

The most recent version of the package can be found  at \url{https://github.com/nickpoison/astsa/}.

In addition, the News and ChangeLog files are at  \url{https://github.com/nickpoison/astsa/blob/master/NEWS.md}.

The webpages for the texts and some help on using R for time series analysis can be found at
 \url{https://nickpoison.github.io/}.  
}
\examples{
tsplot(econ5, ncolm=2, col=2:6, lwd=2, title=colnames(econ5), 
         ylab=c('\%', rep('Billions-USD', 4)))
}
\keyword{datasets}