\name{Hare}
\alias{Hare}
\docType{data}
\title{Snowshoe Hare
}
\description{This is one of the classic studies of predator-prey interactions, the 90-year data set is the number, in thousands, of snowshoe hare pelts purchased by the Hudson's Bay Company (HBC) of Canada. While this is an indirect measure of predation, the assumption is that there is a direct relationship between the number of pelts collected and the number of hare and lynx in the wild.

If you are interested in the brutal story of HBC, see the video \kbd{https://www.nfb.ca/film/other_side_of_the_ledger} or read the article \kbd{https://canadiangeographic.ca/articles/the-untold-story-of-the-hudsons-bay-company}.
} 
\format{
  The format is:
 Time-Series [1:91] from 1845 to 1935: 19.6 19.6 19.6 12 28 ...
}
\note{This data set pairs with \code{\link{Lynx}}.
The data are in  units of one  thousand.
}
\source{From Odum's "Fundamentals of Ecology",  p. 191.
Data listed at:\cr
\kbd{http://people.whitman.edu/~hundledr/courses/M250F03/M250.html}\cr
scroll down to: Chapter 6, Difference Equations.

NB: For some reason, there is not a secure and encrypted version of the site above.
}
\references{You can find demonstrations of astsa capabilities at
\href{https://github.com/nickpoison/astsa/blob/master/fun_with_astsa/fun_with_astsa.md}{FUN WITH ASTSA}.

The most recent version of the package can be found  at \url{https://github.com/nickpoison/astsa/}.

In addition, the News and ChangeLog files are at  \url{https://github.com/nickpoison/astsa/blob/master/NEWS.md}.

The webpages for the texts and some help on using R for time series analysis can be found at
 \url{https://nickpoison.github.io/}. 
}
\seealso{\code{\link{Lynx}}}
\keyword{datasets}
