astsa.col <- function(alpha=1) {  
     u <- c("black","#F6483C","#00BA38","#1874cd","#0D9AC0","#cd1874","#C47700","gray62")
	 grDevices::adjustcolor(u, alpha=alpha)
	 }
