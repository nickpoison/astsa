astsa.col <- function(alpha=1) {  
     u <- c("black","#F6483C","#00BA38","#1773CC","#0D9AC0","#BA23AB","#C47700","gray62")
	 grDevices::adjustcolor(u, alpha=alpha)
	 }
