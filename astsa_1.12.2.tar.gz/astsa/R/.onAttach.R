.onAttach <- function(){ 
             u <- palette('ggplot2') 
			 u[4] = rgb(.09, .45, .80)
	         palette(u)
			 }